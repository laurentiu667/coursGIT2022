#include <iostream>
#include <conio.h>
#include <iomanip>
#include <string>


using namespace std;

int main()
{
	// D�CLARATION DES CONSTANTES

	const double DOLLAR = 1.31674;
	const double EURO = 1.31357;
	const double BAHT = 0.03597;
	const double ROUPIE = 0.01657;
	const double COURONNE = 0.17666;
	const char SYMBOL = '$';
	char deviseInitiale;
	char deviseConversion;

	// D�CLARATION DES VARIABLES

	double montantInitital;
	double montantCanadien;
	double montantConverti;
    int a = 4;
    int b = 20;
    int c = 30;
    int m = 18;
    int n = 15;
    int y = 2;
    int s = 16;

    // AFFICHAGE

	cout << "Entrez le montant \x85 convertir  : ";
	cin >> montantInitital;
	cout << endl << "Entrez la devise de ce montant :";
	cout << endl << endl << setw(a) << "" << setw(b) << left << "$ -> Dollar" << "(Canada)";
	cout << endl << setw(a) << "" << setw(b) << "D -> Dollar" << "(\220tats-unis)";
	cout << endl << setw(a) << "" << setw(b) << "E -> Euro" << "(Union Europ\202enne)";
	cout << endl << setw(a) << "" << setw(b) << "B -> Baht" << "(Tha\213lande)";
	cout << endl << setw(a) << "" << setw(b) << "R -> Roupie" << "(Inde)";
	cout << endl << setw(a) << "" << setw(b) << "C -> Couronne" << "(Danemark)" << setw(s) << "" << "Votre choix : ";
	deviseInitiale = _getch();
	deviseInitiale = toupper(deviseInitiale);
	cout << deviseInitiale;

    //AFFICHAGE II

	cout << endl << endl << "Entrez la devise dans laquelle on fera la conversion : ";
	cout << endl << endl << setw(a) << "" << setw(b) << left << "$ -> Dollar" << "(Canada)";
	cout << endl << setw(a) << "" << setw(b) << "D -> Dollar" << "(\220tats-unis)";
	cout << endl << setw(a) << "" << setw(b) << "E -> Euro" << "(Union Europ\202enne)";
	cout << endl << setw(a) << "" << setw(b) << "B -> Baht" << "(Tha\213lande)";
	cout << endl << setw(a) << "" << setw(b) << "R -> Roupie" << "(Inde)";
	cout << endl << setw(a) << "" << setw(b) << "C -> Couronne" << "(Danemark)" << setw(s) << "" << "Votre choix : ";

	deviseConversion = _getch();
	deviseConversion = toupper(deviseConversion);
	cout << deviseConversion;

	// Conversion de montantInitial en dollars canadiens

	if (deviseInitiale == 'D')
		montantCanadien = montantInitital * DOLLAR;
	else if (deviseInitiale == 'E')
		montantCanadien = montantInitital * EURO;
	else if (deviseInitiale == 'B')
		montantCanadien = montantInitital * BAHT;
	else if (deviseInitiale == 'R')
		montantCanadien = montantInitital * ROUPIE;
	else if (deviseInitiale == 'C')
		montantCanadien = montantInitital * COURONNE;
	else
	{
		montantCanadien = montantInitital;
		deviseInitiale = SYMBOL;
	}

	// Conversion de montantCanadien dans la devise voulue

	if (deviseConversion == 'D')
		montantConverti = montantCanadien / DOLLAR;
	else if (deviseConversion == 'E')
		montantConverti = montantCanadien / EURO;
	else if (deviseConversion == 'B')
		montantConverti = montantCanadien / BAHT;
	else if (deviseConversion == 'R')
		montantConverti = montantCanadien / ROUPIE;
	else if (deviseConversion == 'C')
		montantConverti = montantCanadien / COURONNE;
	else
	{
		montantConverti = montantCanadien;
		montantCanadien = montantInitital;
		deviseConversion = SYMBOL;
	}

	//AFFICHAGE

	cout << endl << endl << left << setw(m) << "Montant initial  :" << right << setw(15) << fixed << setprecision(y) << montantInitital << " " << deviseInitiale;
	cout << endl << endl << left << setw(m) << "Montant converti :" << right << setw(15) << fixed << setprecision(y) << montantConverti << " " << deviseConversion;

	_getch();
}