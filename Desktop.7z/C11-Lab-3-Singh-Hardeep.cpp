#include <iostream>
#include <conio.h>
#include <string>
#include <iomanip>

#include "../../cvm 21.h"

using namespace std;
int main()
{
	// Constances 

	const double TPS			= 0.05;
	const double TVQ			= 0.09975; 
	const double TARIFPARJOUR 	= 0.42238;
	const double TARIF_1		= 0.06319;
	const double TARIF_2		= 0.09749;
	const int LARG1				= 120;
	const string titre1			= "HYDRO-QU\x90""BEC";

	// Variables 

	string nom, prenom;
	unsigned int nbJour, nbKwHres;
	int x						= 41;
	

	// TITRE 

	size_t LARG_titre1 = titre1.size();
	cout << right << setw((LARG1 - LARG_titre1) / 2 + LARG_titre1) << titre1 << endl << endl;

	// Getline
	cout << left;
	cout << "\n\n\n" << setw(x) << "Quel est votre pr\x82nom " << ": ";
	getline(cin, prenom);

	cout << "\n" << setw(x) << "Quel est votre nom " << ": ";
	getline(cin, nom);

	cout << "\n\n" << setw(x) << " Quelle est votre consommation en kWh" << ": ";
	cin >> nbKwHres;

	cout << "\n" << setw(x) << "Sur combien de jours" << ": ";
	cin >> nbJour; 

	cout << "\n\n\n" << right << setw(x) << "Appuyer sur une touche pour continuer";


	_getch();
	clrscr();

	////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Titre

	const int LARG				= 120;
	const string titre			= "HYDRO-QU\x90""BEC";
	size_t LARG_titre			= titre.size();
	cout << right << setw((LARG - LARG_titre) / 2 + LARG_titre) << titre << endl << endl;


	// If Else

	double prix_1;
	double prix_2;


	if (nbKwHres > (40 * nbJour))
	{
		prix_1 = TARIF_1 * (40 * nbJour);
		prix_2 = TARIF_2 * (nbKwHres - (40 * nbJour));
	}
	else 
	{
		prix_1 = TARIF_1 * nbKwHres;
		prix_2 = 0;
	}

	// Variable et Constances

	double redevance = nbJour * TARIFPARJOUR;
	double tps = prix_1 + prix_2 + redevance * TPS;
	double tvq = prix_1 + prix_2 + redevance * TVQ;
	double totalFacture = prix_1 + prix_2 + redevance + tps + tvq;
	double tpS = 5;
	double tvQ = 9.975;
	int s = 32;
	int y = 13;
	int z = 5;
	int v = 2;



	// Cout total

	cout << left << fixed << setprecision(2)

		<< "FACTURE D'\220LECTRICIT\220 DE : " << prenom << " " << nom << endl << endl << endl
		<< setw(s) << "REDEVENACE D'ABONNEMENT:" << setw(y) << right << fixed << setprecision(v) << redevance << " $    " << nbJour << " jour(s) x " << setprecision(z) << TARIFPARJOUR << " $" << left << endl << endl << endl
		<< setw(51) << "CONSOMMATION:" << nbKwHres << " kWh" << endl << endl
		<< setw(s) << "  Les 40 premiers kWh\x5cjour:" << fixed << setprecision(v) << right << setw(y) << prix_1 << " $    " << (40 * nbJour) << " kWh x " << setprecision(z) << TARIF_1 << " $" << endl << endl
		<< setw(s) << left << "  Le reste de la consommation:" << setprecision(v) << right << setw(y) << prix_2 << " $    " << (nbKwHres - (40 * nbJour)) << " kWh x " << setprecision(z) << TARIF_2 << " $" << endl << endl << endl
		<< setw(s) << left << "TPS" << setw(y) << right << setprecision(v) << tps << " $" << setw(5) << setprecision(0) << tpS << " %" << endl << endl
		<< setw(s) << left << "TVQ" << setw(y) << right << setprecision(v) << tvq << " $" << setw(9) << setprecision(3) << tvQ << " %" << endl << endl
		<< setw(s) << "" << setfill('-') << setw(15) << " " << setfill(' ') << endl
		<< setw(39) << left << "TOTAL" << left << setprecision(v) << totalFacture << " $";




	_getch();
}